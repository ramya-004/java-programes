//Define Functional Interface MyCube
package com.tnsif.daynineteen.v1;

@FunctionalInterface
public interface MyCube {
	int getCube(int no);
	//void show(); not allow more than one abstract method
}
