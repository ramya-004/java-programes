//can't inherit final classes
package com.tnsif.daynine;

public class StringSubClass extends String {

	public static void main(String[] args) {
		

	}
}