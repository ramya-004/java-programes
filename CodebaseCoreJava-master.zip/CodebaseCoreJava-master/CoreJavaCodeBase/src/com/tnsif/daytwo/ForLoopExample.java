//Program to demonstrate for loop
package com.tnsif.daytwo;

public class ForLoopExample {
	public static void main(String[] args) 
	{	
		for(int i = 1; i<=1000 ; i++)   //(int i = 1000; i<=1;i--)
		{	
			System.out.print("Value of i:");
			System.out.println(i);
		}
	}
}
